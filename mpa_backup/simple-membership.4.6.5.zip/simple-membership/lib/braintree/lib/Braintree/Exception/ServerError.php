<?php

namespace Braintree\Exception;

use Braintree\Exception;

/**
 * Raised when an unexpected server error occurs.
 */
class ServerError extends Exception
{
}
