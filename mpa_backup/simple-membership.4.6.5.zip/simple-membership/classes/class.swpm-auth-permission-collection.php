<?php
/**
 * SwpmAuthPermissionCollection
 */
class SwpmAuthPermissionCollection extends SwpmPermissionCollection{
    //NOP
}
